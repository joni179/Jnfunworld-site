// নতুন সেকশন যোগ করতে এই তালিকায় একটা লাইন বাড়ান: [ফোল্ডার, আইকন, নাম, রং]
const NAV=[["games","🎮","গেম","#ffc93c"],["images","🖼️","ছবি","#8be0c4"],["quiz","❓","কুইজ","#ff9ec0"],["puzzles","🧩","ধাঁধা","#b9a6ff"],["videos","🎬","ভিডিও","#ff9f6e"],["tools","🛠️","টুলস","#8ec9ff"],["music","🎵","মিউজিক","#c8e86b"]];
const root=document.body.dataset.root||"";
document.getElementById("top").innerHTML=`<a class="logo" href="${root}index.html">JN<span>funworld</span></a><nav>${NAV.map(n=>`<a href="${root}${n[0]}/index.html">${n[1]} ${n[2]}</a>`).join("")}</nav>`;
const home=document.getElementById("home");
if(home)home.innerHTML=NAV.map(n=>`<a class="card sec" style="--c:${n[3]}" href="${n[0]}/index.html"><b>${n[1]}</b><h3>${n[2]}</h3></a>`).join("");
const grid=document.getElementById("grid");
if(grid){
  const sec=document.body.dataset.section,items=window.ITEMS||[];
  const card=i=>{
    let m="",l="";
    if(sec==="images")m=`<img src="${i.file}" alt="${i.title}" loading="lazy">`;
    else if(sec==="videos")m=`<video controls preload="metadata" src="${i.file}"></video>`;
    else if(sec==="music")m=`<audio controls src="${i.file}"></audio>`;
    else l=`<a class="btn" href="${i.file}">খুলুন →</a>`;
    return `<article class="card">${m}<h3>${i.title}</h3><p>${i.desc||""}</p>${l}</article>`;
  };
  const show=t=>{const f=items.filter(i=>(i.title+" "+(i.desc||"")).toLowerCase().includes(t.toLowerCase()));
    grid.innerHTML=f.length?f.map(card).join(""):'<p class="empty">কিছু পাওয়া যায়নি। এই ফোল্ডারের data.js ফাইলে নতুন আইটেম যোগ করুন।</p>'};
  show("");document.getElementById("q").oninput=e=>show(e.target.value);
}
